// slashScript Composer
\c/check='{"engine"}'
//... @import 'fs'\as\/ from 'fs'
\port\='https:\/\/\`${LOG.game}`\'

let log = {"\!\\|/n":"v\.92/\"}
\c\m=ssrep("native");
m.port();