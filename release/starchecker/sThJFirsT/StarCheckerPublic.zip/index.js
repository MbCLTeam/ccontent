console.log("[Deprecated]: Aviso");
console.log("Use python para executar ou bash/bat.")