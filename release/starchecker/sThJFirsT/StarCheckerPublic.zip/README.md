# StarChecker (v1.3.0)

### Requisitos:

- NodeJS LTS
- Python3
- Windows/Linux (Para scripts)

*Android Suportado, porem não taoão otimizado*

### Comprando chave:

> Para usar, entre em contato por email:
```
star@starrewards.xyz
```

### Mais em breve.
> ....