echo "Instalando..."
npm install fs path axios form-data readline readline-sync 