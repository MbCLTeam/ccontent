import os #line:1:import os #line:3:import os
import subprocess #line:2:import subprocess #line:4:import subprocess
import platform #line:3:import platform #line:5:import platform
subprocess .call (["node","engine"])#line:4:subprocess .call (["node","engine"])#line:7:subprocess.call(["node", "engine"])
def clear_screen ():#line:5:def clear_screen ():#line:10:def clear_screen():
    os .system ("cls"if os .name =="nt"else "clear")#line:6:os .system ("cls"if os .name =="nt"else "clear")#line:11:os.system("cls" if os.name == "nt" else "clear")
def print_color (O000OOO0OO0000O00 ,O000OOO00OOOOOOOO ):#line:7:def print_color (OO0O0OOO00OOO0OOO ,OO000O00000O00OO0 ):#line:13:def print_color(text, color_code):
    if os .name =="nt":#line:8:if os .name =="nt":#line:14:if os.name == "nt":
        os .system (f"color {O000OOO00OOOOOOOO} && echo {O000OOO0OO0000O00}")#line:9:os .system (f"color {OO000O00000O00OO0} && echo {OO0O0OOO00OOO0OOO}")#line:15:os.system(f"color {color_code} && echo {text}")
    else :#line:10:else :#line:16:else:
        print (O000OOO0OO0000O00 )#line:11:print (OO0O0OOO00OOO0OOO )#line:17:print(text)
system_name =platform .system ()#line:12:system_name =platform .system ()#line:19:system_name = platform.system()
if system_name not in ["Windows","Linux"]:#line:13:if system_name not in ["Windows","Linux"]:#line:20:if system_name not in ["Windows", "Linux"]:
    print_color (f"O sistema {system_name} não é compatível com o StarChecker.","0c")#line:14:print_color (f"O sistema {system_name} não é compatível com o StarChecker.","0c")#line:21:print_color(f"O sistema {system_name} não é compatível com o StarChecker.", "0c")
    exit ()#line:15:exit ()#line:22:exit()
wm1 =f"\x1b[32m[@StarChecker]: v1.3.0 | Private\x1b[0m"#line:16:wm1 =f"\x1b[32m[@StarChecker]: v1.3.0 | Private\x1b[0m"#line:24:wm1 = f"\x1b[32m[@StarChecker]: v1.3.0 | Private\x1b[0m"
wm2 =f"\x1b[33m[Criador]: GsLKS (Github) | @trollgamesz (Insta)\x1b[0m"#line:17:wm2 =f"\x1b[33m[Criador]: GsLKS (Github) | @trollgamesz (Insta)\x1b[0m"#line:25:wm2 = f"\x1b[33m[Criador]: GsLKS (Github) | @trollgamesz (Insta)\x1b[0m"
wm3 =f"\x1b[91m[StarRewards]: discord.gg/QAyFXtJwY7\x1b[0m"#line:18:wm3 =f"\x1b[91m[StarRewards]: discord.gg/QAyFXtJwY7\x1b[0m"#line:26:wm3 = f"\x1b[91m[StarRewards]: discord.gg/QAyFXtJwY7\x1b[0m"
wm =f"{wm1}\n{wm2}\n{wm3}\n\n\n"#line:19:wm =f"{wm1}\n{wm2}\n{wm3}\n\n\n"#line:27:wm = f"{wm1}\n{wm2}\n{wm3}\n\n\n"
clear_screen ()#line:20:clear_screen ()#line:29:clear_screen()
print (wm )#line:21:print (wm )#line:31:print(wm)
print_color ("[1]: Separador de Contas","0e")#line:22:print_color ("[1]: Separador de Contas","0e")#line:32:print_color("[1]: Separador de Contas", "0e")
print_color ("[2]: Checker v1","0e")#line:23:print_color ("[2]: Checker v1","0e")#line:33:print_color("[2]: Checker v1", "0e")
print_color ("[3]: Creditos","0e")#line:24:print_color ("[3]: Creditos","0e")#line:34:print_color("[3]: Creditos", "0e")
print_color ("[0]: Sair","0e")#line:25:print_color ("[0]: Sair","0e")#line:35:print_color("[0]: Sair", "0e")
choice =input ("\nEscolha uma opção (0 a 3): ")#line:26:choice =input ("\nEscolha uma opção (0 a 3): ")#line:36:choice = input("\nEscolha uma opção (0 a 3): ")
if choice in ["0","1","2","3"]:#line:27:if choice in ["0","1","2","3"]:#line:38:if choice in ["0", "1", "2", "3"]:
    if choice =="1":#line:28:if choice =="1":#line:39:if choice == "1":
        count =1 #line:29:count =1 #line:40:count = 1
        options =[]#line:30:options =[]#line:41:options = []
        for file in os .listdir ("shards/filter_modules"):#line:31:for file in os .listdir ("shards/filter_modules"):#line:42:for file in os.listdir("shards/filter_modules"):
            if file .endswith (".js"):#line:32:if file .endswith (".js"):#line:43:if file.endswith(".js"):
                base =os .path .splitext (file )[0 ]#line:33:base =os .path .splitext (file )[0 ]#line:44:base = os.path.splitext(file)[0]
                option =base [0 ].upper ()+base [1 :]#line:34:option =base [0 ].upper ()+base [1 :]#line:45:option = base[0].upper() + base[1:]
                options .append (option )#line:35:options .append (option )#line:46:options.append(option)
                print_color (f"[{count}]: {option}","0e")#line:36:print_color (f"[{count}]: {option}","0e")#line:47:print_color(f"[{count}]: {option}", "0e")
                count +=1 #line:37:count +=1 #line:48:count += 1
        print_color (f"[0]: Voltar para o menu anterior","0e")#line:38:print_color (f"[0]: Voltar para o menu anterior","0e")#line:49:print_color(f"[0]: Voltar para o menu anterior", "0e")
        sub_choice =int (input (f"Escolha um serviço (0 a {count-1}): "))#line:39:sub_choice =int (input (f"Escolha um serviço (0 a {count-1}): "))#line:50:sub_choice = int(input(f"Escolha um serviço (0 a {count-1}): "))
        if 0 <=sub_choice <=len (options ):#line:40:if 0 <=sub_choice <=len (options ):#line:51:if 0 <= sub_choice <= len(options):
            if sub_choice ==0 :#line:41:if sub_choice ==0 :#line:52:if sub_choice == 0:
                os .system ("python "+__file__ )#line:42:os .system ("python "+__file__ )#line:53:os.system("python " + __file__)
            else :#line:43:else :#line:54:else:
                selected_service =options [sub_choice -1 ]#line:44:selected_service =options [sub_choice -1 ]#line:55:selected_service = options[sub_choice - 1]
                selected_file =f"shards/filter_modules/{selected_service.lower()}.js"#line:45:selected_file =f"shards/filter_modules/{selected_service.lower()}.js"#line:56:selected_file = f"shards/filter_modules/{selected_service.lower()}.js"
                if os .path .exists (selected_file ):#line:46:if os .path .exists (selected_file ):#line:57:if os.path.exists(selected_file):
                    os .system (f"node {selected_file}")#line:47:os .system (f"node {selected_file}")#line:58:os.system(f"node {selected_file}")
                else :#line:48:else :#line:59:else:
                    print_color ("Opção inválida.","0c")#line:49:print_color ("Opção inválida.","0c")#line:60:print_color("Opção inválida.", "0c")
        else :#line:50:else :#line:61:else:
            print_color ("Escolha uma opção válida.","0c")#line:51:print_color ("Escolha uma opção válida.","0c")#line:62:print_color("Escolha uma opção válida.", "0c")
    elif choice =="2":#line:52:elif choice =="2":#line:63:elif choice == "2":
        print_color ("Não está disponível atualmente.","0c")#line:53:print_color ("Não está disponível atualmente.","0c")#line:64:print_color("Não está disponível atualmente.", "0c")
    elif choice =="3":#line:54:elif choice =="3":#line:65:elif choice == "3":
        print_color ("[Criador]: GsLKS (Github) | @trollgamesz (Insta)","0c")#line:55:print_color ("[Criador]: GsLKS (Github) | @trollgamesz (Insta)","0c")#line:66:print_color("[Criador]: GsLKS (Github) | @trollgamesz (Insta)", "0c")
        print_color ("[Site]: https://starrewards.xyz","0c")#line:56:print_color ("[Site]: https://starrewards.xyz","0c")#line:67:print_color("[Site]: https://starrewards.xyz", "0c")
    elif choice =="0":#line:57:elif choice =="0":#line:68:elif choice == "0":
        exit ()#line:58:exit ()#line:69:exit()
else :#line:59:else :#line:70:else:
    print_color ("Escolha uma opção válida (0 a 3).","0c")#line:60:print_color ("Escolha uma opção válida (0 a 3).","0c")#line:71:print_color("Escolha uma opção válida (0 a 3).", "0c")
    