const oqg = "onlyfans"
const axios = require('axios');
const config = require('../../config.json');


async function makeRequest() {
  try {
    const response = await axios.get(`https://rest.starrewards.xyz/keys?k=${config.chave}`);
    const data = response.data;

    if (data.status === 'OK') {
      
    } else if (data.status === 'down') {
      console.log("A chave configurada está expirada, entre em contato com o suporte.");
      process.exit(1);
    } else if (data.status === 'Sua chave não é válida.') {
      console.log("A chave configurada é inválida.");
      process.exit(1);
    } else {
      console.log("A chave não existe.");
      process.exit(1);
    }
  } catch (error) {
    if (error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
      console.log("O servidor está fora do ar ou você está sem conexão com a internet.");
      process.exit(1);
    }
  }
}

(async () => {
  await makeRequest();
  // Continue with the rest of your code here
  const fs = require('fs');
const path = require('path');

const service = oqg;
const inputRootDirectory = './Cluster/logs'; // Replace with the root directory path
const outputFile = './Cluster/stock/' + oqg + '.txt'; // Replace with the desired output file path

function findAccountsInFile(fileName, service) {
    const data = fs.readFileSync(fileName, 'utf8');
    const lines = data.split('===============');
    const accounts = [];
    lines.forEach((line) => {
        if (line.includes(service)) {
            const usernameMatch = line.match(/Username: (.*)/);
            const passwordMatch = line.match(/Password: (.*)/);

            if (usernameMatch && passwordMatch) {
                const username = usernameMatch[1];
                const password = passwordMatch[1];
                accounts.push({ username, password });
            }
        }
    });
    return accounts;
}

function saveAccounts(accounts, outputFile) {
    let content = '';
    accounts.forEach((account) => {
        content += `${account.username}:${account.password} | starrewards.xyz\n`;
    });
    fs.writeFileSync(outputFile, content, { flag: 'a' });
}

function searchAccountsInDirectory(directoryPath) {
    const files = fs.readdirSync(directoryPath);

    const accounts = [];

    files.forEach((file) => {
        const filePath = path.join(directoryPath, file);

        if (fs.lstatSync(filePath).isFile() && file === 'Passwords.txt') {
            const fileAccounts = findAccountsInFile(filePath, service);
            accounts.push(...fileAccounts);
        } else if (fs.lstatSync(filePath).isDirectory()) {
            const subDirectoryAccounts = searchAccountsInDirectory(filePath);
            accounts.push(...subDirectoryAccounts);
        }
    });

    return accounts;
}

const accounts = searchAccountsInDirectory(inputRootDirectory);

if (accounts.length > 0) {
    saveAccounts(accounts, outputFile);
    console.log('Contas encontradas foram salvas em', outputFile);
} else {
    console.log('Nenhuma conta encontrada para o serviço', service);
}

})();



